document.addEventListener("DOMContentLoaded", function() {
  $('.preloader-background').delay(10).fadeOut('slow');
});
